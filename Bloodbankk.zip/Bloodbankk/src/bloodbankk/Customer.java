package bloodbankk;
/**
 *
 * @author Iqbal Elham
 */
public class Customer {
    String name;
    String Lname;
    int age;
    long contactno; 
}
